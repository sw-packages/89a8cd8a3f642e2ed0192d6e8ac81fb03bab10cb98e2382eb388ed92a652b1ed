#if defined(SIMDJSON_CONDITIONAL_INCLUDE) && !defined(SIMDJSON_SRC_GENERIC_DEPENDENCIES_H)
#error generic/dependencies.h must be included before generic/amalgamated.h!
#endif

#include <generic/base.h>
#include <generic/dom_parser_implementation.h>
#include <generic/json_character_block.h>
